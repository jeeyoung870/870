# numpy : 배열 계산 기능, 반올림, 버림 기능(floorm ceil, power)
# pandas : 데이터프레임으로 데이터 입력, 가공(describe, groupby)
# matploplib : 그래프 그리기(plot, hist, bar)
# pip install numpy
# pip install numpy-financial
# pip install pandas
# pip install matplotlib
